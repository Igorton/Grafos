﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Vertice
{
    public string Nome; // Nome do vértice (ex: "A", "1", etc.)
    public List<Aresta> ArestasLigadas = new(); // Lista de arestas ligadas a esse vértice

    public Vertice(string nome)
    {
        Nome = nome; // Guarda o nome
    }
}

class Aresta
{
    public Vertice De; // De onde sai
    public Vertice Para; // Para onde vai
    public double Peso; // Peso da aresta

    public Aresta(Vertice de, Vertice para, double peso)
    {
        De = de;
        Para = para;
        Peso = peso;
    }
}

class Grafo
{
    private Dictionary<string, Vertice> vertices = new(); // Dicionário com vértices pelo nome
    private List<Aresta> arestas = new(); // Lista de arestas

    public Vertice AdicionarVertice(string nome)
    {
        if (!vertices.ContainsKey(nome)) // Se ainda não existe
        {
            vertices[nome] = new Vertice(nome); // Cria novo
        }
        return vertices[nome];
    }

    public void AdicionarAresta(string de, string para, double peso)
    {
        var v1 = AdicionarVertice(de); // Cria ou pega vértice de origem
        var v2 = AdicionarVertice(para); // Cria ou pega vértice de destino
        var novaAresta = new Aresta(v1, v2, peso); // Cria aresta
        v1.ArestasLigadas.Add(novaAresta); // Liga no vértice de origem
        v2.ArestasLigadas.Add(novaAresta); // Liga no vértice de destino
        arestas.Add(novaAresta); // Adiciona na lista geral
    }

    public void MostrarGrafo()
    {
        Console.WriteLine("\n--- VÉRTICES ---");
        foreach (var item in vertices)
        {
            Console.WriteLine("Vértice: " + item.Key);
        }

        Console.WriteLine("\n--- ARESTAS ---");
        for (int i = 0; i < arestas.Count; i++)
        {
            var a = arestas[i];
            Console.WriteLine($"[{i}] {a.De.Nome} -> {a.Para.Nome} (Peso: {a.Peso})");
        }
    }

    public void CarregarDeArquivo(string caminho)
    {
        var linhas = File.ReadAllLines(caminho); // Lê todas as linhas do arquivo

        foreach (var linha in linhas.Skip(1)) // Ignora a primeira linha (quantidade de vértices)
        {
            var partes = linha.Split(); // Divide a linha por espaço
            if (partes.Length == 3)
            {
                AdicionarAresta(partes[0], partes[1], double.Parse(partes[2])); // Cria a aresta
            }
        }

        Console.WriteLine("Grafo carregado com sucesso!");
    }

    public void Dijkstra(string inicio, string fim)
    {
        var distancia = new Dictionary<string, double>(); // Guarda distâncias
        var anterior = new Dictionary<string, string>(); // Guarda o caminho
        var visitados = new HashSet<string>(); // Marca os visitados

        foreach (var nome in vertices.Keys)
        {
            distancia[nome] = int.MaxValue; // Começa infinito
        }

        distancia[inicio] = 0; // A distância até o início é 0

        while (visitados.Count < vertices.Count)
        {
            string atual = null;
            int menorDistancia = double.MaxValue;

            foreach (var v in vertices.Keys)
            {
                if (!visitados.Contains(v) && distancia[v] < menorDistancia)
                {
                    menorDistancia = distancia[v];
                    atual = v;
                }
            }

            if (atual == null || atual == fim) break; // Parar se chegou no fim

            visitados.Add(atual); // Marca como visitado

            foreach (var aresta in vertices[atual].ArestasLigadas)
            {
                var vizinho = aresta.De.Nome == atual ? aresta.Para.Nome : aresta.De.Nome;

                if (visitados.Contains(vizinho)) continue; // Se já visitado, pula

                int novaDistancia = distancia[atual] + aresta.Peso;

                if (novaDistancia < distancia[vizinho])
                {
                    distancia[vizinho] = novaDistancia;
                    anterior[vizinho] = atual;
                }
            }
        }

        // Mostra caminho
        if (!anterior.ContainsKey(fim) && inicio != fim)
        {
            Console.WriteLine("Não foi possível encontrar um caminho.");
            return;
        }

        var caminho = new Stack<string>();
        var atualVertice = fim;

        while (atualVertice != null)
        {
            caminho.Push(atualVertice);
            anterior.TryGetValue(atualVertice, out atualVertice);
        }

        Console.WriteLine("\nCaminho mais curto:");
        Console.WriteLine(string.Join(" -> ", caminho));
        Console.WriteLine("Custo total: " + distancia[fim]);
    }

    public void SubstituirPesoAresta(int indice, int novoPeso)
    {
        if (indice >= 0 && indice < arestas.Count)
        {
            arestas[indice].Peso = novoPeso;
        }
    }

    public void SubstituirNomeVertice(string antigo, string novo)
    {
        if (vertices.ContainsKey(antigo))
        {
            var v = vertices[antigo];
            vertices.Remove(antigo);
            v.Nome = novo;
            vertices[novo] = v;
        }
    }

    public void RemoverVertice(string nome)
    {
        if (vertices.ContainsKey(nome))
        {
            var v = vertices[nome];

            // Remove as arestas ligadas a esse vértice
            arestas.RemoveAll(a => a.De == v || a.Para == v);

            foreach (var vert in vertices.Values)
            {
                vert.ArestasLigadas.RemoveAll(a => a.De == v || a.Para == v);
            }

            vertices.Remove(nome);
        }
    }

    public void RemoverAresta(int indice)
    {
        if (indice >= 0 && indice < arestas.Count)
        {
            var a = arestas[indice];
            a.De.ArestasLigadas.Remove(a);
            a.Para.ArestasLigadas.Remove(a);
            arestas.RemoveAt(indice);
        }
    }

    public bool VerificarAdjacencia(string a, string b)
    {
        if (!vertices.ContainsKey(a) || !vertices.ContainsKey(b)) return false;

        return vertices[a].ArestasLigadas.Any(x => x.De.Nome == b || x.Para.Nome == b);
    }
}

class Programa
{
    static void Main()
    {
        var grafo = new Grafo();
        bool rodando = true;

        while (rodando)
        {
            Console.WriteLine("\n=== MENU DO GRAFO ===");
            Console.WriteLine("1 - Carregar grafo de arquivo");
            Console.WriteLine("2 - Mostrar grafo");
            Console.WriteLine("3 - Adicionar vértice");
            Console.WriteLine("4 - Adicionar aresta");
            Console.WriteLine("5 - Ver se dois vértices são adjacentes");
            Console.WriteLine("6 - Trocar nome de vértice");
            Console.WriteLine("7 - Trocar peso de aresta");
            Console.WriteLine("8 - Remover vértice");
            Console.WriteLine("9 - Remover aresta");
            Console.WriteLine("10 - Dijkstra (caminho mais curto)");
            Console.WriteLine("0 - Sair");
            Console.Write("Escolha uma opção: ");

            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    Console.Write("Caminho do arquivo: ");
                    string caminho = Console.ReadLine();
                    grafo.CarregarDeArquivo(caminho);
                    break;
                case "2":
                    grafo.MostrarGrafo();
                    break;
                case "3":
                    Console.Write("Nome do vértice: ");
                    grafo.AdicionarVertice(Console.ReadLine());
                    break;
                case "4":
                    Console.Write("Vértice de origem: ");
                    string origem = Console.ReadLine();
                    Console.Write("Vértice de destino: ");
                    string destino = Console.ReadLine();
                    Console.Write("Peso da aresta: ");
                    double peso = double.Parse(Console.ReadLine());
                    grafo.AdicionarAresta(origem, destino, peso);
                    break;
                case "5":
                    Console.Write("Vértice 1: ");
                    string v1 = Console.ReadLine();
                    Console.Write("Vértice 2: ");
                    string v2 = Console.ReadLine();
                    Console.WriteLine(grafo.VerificarAdjacencia(v1, v2) ? "São adjacentes." : "Não são adjacentes.");
                    break;
                case "6":
                    Console.Write("Nome antigo: ");
                    string antigo = Console.ReadLine();
                    Console.Write("Novo nome: ");
                    string novo = Console.ReadLine();
                    grafo.SubstituirNomeVertice(antigo, novo);
                    break;
                case "7":
                    Console.Write("Índice da aresta: ");
                    int iA = int.Parse(Console.ReadLine());
                    Console.Write("Novo peso: ");
                    int novoPeso = int.Parse(Console.ReadLine());
                    grafo.SubstituirPesoAresta(iA, novoPeso);
                    break;
                case "8":
                    Console.Write("Nome do vértice para remover: ");
                    grafo.RemoverVertice(Console.ReadLine());
                    break;
                case "9":
                    Console.Write("Índice da aresta para remover: ");
                    grafo.RemoverAresta(int.Parse(Console.ReadLine()));
                    break;
                case "10":
                    Console.Write("Origem: ");
                    string origemD = Console.ReadLine();
                    Console.Write("Destino: ");
                    string destinoD = Console.ReadLine();
                    grafo.Dijkstra(origemD, destinoD);
                    break;
                case "0":
                    rodando = false;
                    break;
                default:
                    Console.WriteLine("Opção inválida.");
                    break;
            }
        }
    }
}
